CREATE DATABASE IF NOT EXISTS `cdaps`;

USE cdaps;

DROP TABLE IF EXISTS `asistencias`;

CREATE TABLE `asistencias` (
  `id_asistencia` int(11) NOT NULL AUTO_INCREMENT,
  `id_personas` int(11) NOT NULL,
  `fecha` date NOT NULL COMMENT 'día de la asistencia',
  `hora` time NOT NULL,
  PRIMARY KEY (`id_asistencia`),
  KEY `id_persona` (`id_personas`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `asistencias` VALUES("1","3","2017-09-19","09:21:23");



DROP TABLE IF EXISTS `auditoria`;

CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `actividad` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `status` enum('0','1') COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `auditoria` VALUES("1","admin ","Ha iniciado sesi&oacute;n","2017-11-24","13:01:28","0");
INSERT INTO `auditoria` VALUES("2","admin ","Ha iniciado sesi&oacute;n","2017-11-24","16:05:46","0");
INSERT INTO `auditoria` VALUES("3","Admin ","Ha Inhabilitado a una persona","2017-11-24","16:11:11","0");
INSERT INTO `auditoria` VALUES("4","Admin ","Ha Inhabilitado a una persona","2017-11-24","16:12:34","0");
INSERT INTO `auditoria` VALUES("5","admin ","Ha iniciado sesi&oacute;n","2017-11-26","19:49:10","0");
INSERT INTO `auditoria` VALUES("6","Admin ","Ha Censado a Centro de Alimentacion Pueblo Manzo","2017-11-26","19:51:37","0");
INSERT INTO `auditoria` VALUES("7","admin ","Ha iniciado sesi&oacute;n","2017-11-26","21:26:13","0");
INSERT INTO `auditoria` VALUES("8","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:37:59","0");
INSERT INTO `auditoria` VALUES("9","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:38:10","0");
INSERT INTO `auditoria` VALUES("10","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:39:31","0");
INSERT INTO `auditoria` VALUES("11","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:39:45","0");
INSERT INTO `auditoria` VALUES("12","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:40:48","0");
INSERT INTO `auditoria` VALUES("13","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:43:23","0");
INSERT INTO `auditoria` VALUES("14","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:43:43","0");
INSERT INTO `auditoria` VALUES("15","Admin ","Ha modificado los datos de Carla Stepha Natera","2017-11-26","21:46:24","0");
INSERT INTO `auditoria` VALUES("16","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:46:41","0");
INSERT INTO `auditoria` VALUES("17","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:48:09","0");
INSERT INTO `auditoria` VALUES("18","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:48:19","0");
INSERT INTO `auditoria` VALUES("19","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:49:19","0");
INSERT INTO `auditoria` VALUES("20","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:49:46","0");
INSERT INTO `auditoria` VALUES("21","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:50:29","0");
INSERT INTO `auditoria` VALUES("22","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:51:06","0");
INSERT INTO `auditoria` VALUES("23","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:52:00","0");
INSERT INTO `auditoria` VALUES("24","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:52:57","0");
INSERT INTO `auditoria` VALUES("25","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:55:44","0");
INSERT INTO `auditoria` VALUES("26","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:57:44","0");
INSERT INTO `auditoria` VALUES("27","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:58:40","0");
INSERT INTO `auditoria` VALUES("28","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:59:17","0");
INSERT INTO `auditoria` VALUES("29","Admin ","Ha Inhabilitado a una persona","2017-11-26","21:59:45","0");
INSERT INTO `auditoria` VALUES("30","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:01:20","0");
INSERT INTO `auditoria` VALUES("31","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:01:39","0");
INSERT INTO `auditoria` VALUES("32","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:02:30","0");
INSERT INTO `auditoria` VALUES("33","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:02:38","0");
INSERT INTO `auditoria` VALUES("34","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:02:48","0");
INSERT INTO `auditoria` VALUES("35","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:03:48","0");
INSERT INTO `auditoria` VALUES("36","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:04:52","0");
INSERT INTO `auditoria` VALUES("37","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:05:42","0");
INSERT INTO `auditoria` VALUES("38","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:05:49","0");
INSERT INTO `auditoria` VALUES("39","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:07:48","0");
INSERT INTO `auditoria` VALUES("40","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:08:13","0");
INSERT INTO `auditoria` VALUES("41","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:08:41","0");
INSERT INTO `auditoria` VALUES("42","Admin ","Ha modificado los datos de Centro de Alimentacion Pueblo Manzo","2017-11-26","22:10:50","0");
INSERT INTO `auditoria` VALUES("43","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:13:02","0");
INSERT INTO `auditoria` VALUES("44","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:14:30","0");
INSERT INTO `auditoria` VALUES("45","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:15:17","0");
INSERT INTO `auditoria` VALUES("46","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:15:38","0");
INSERT INTO `auditoria` VALUES("47","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:15:45","0");
INSERT INTO `auditoria` VALUES("48","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:16:24","0");
INSERT INTO `auditoria` VALUES("49","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:16:37","0");
INSERT INTO `auditoria` VALUES("50","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:16:45","0");
INSERT INTO `auditoria` VALUES("51","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:16:57","0");
INSERT INTO `auditoria` VALUES("52","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:17:17","0");
INSERT INTO `auditoria` VALUES("53","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:17:56","0");
INSERT INTO `auditoria` VALUES("54","Admin ","Ha Inhabilitado a una persona","2017-11-26","22:18:25","0");
INSERT INTO `auditoria` VALUES("55","admin ","Ha iniciado sesi&oacute;n","2017-11-27","07:28:24","0");
INSERT INTO `auditoria` VALUES("56","Admin ","Ha Inhabilitado a una persona","2017-11-27","07:28:37","0");
INSERT INTO `auditoria` VALUES("57","admin ","Ha iniciado sesi&oacute;n","2017-11-27","13:51:29","0");
INSERT INTO `auditoria` VALUES("58","Admin ","Ha Inhabilitado a una persona","2017-11-27","13:53:01","0");
INSERT INTO `auditoria` VALUES("59","Admin ","Ha Inhabilitado a una persona","2017-11-27","13:53:58","0");
INSERT INTO `auditoria` VALUES("60","Admin ","Ha Inhabilitado a una persona","2017-11-27","13:58:40","0");
INSERT INTO `auditoria` VALUES("61","Admin ","Ha Inhabilitado a una persona","2017-11-27","14:04:00","0");
INSERT INTO `auditoria` VALUES("62","Admin ","Ha Inhabilitado a una persona","2017-11-27","14:04:49","0");
INSERT INTO `auditoria` VALUES("63","Admin ","Ha Inhabilitado a una persona","2017-11-27","14:04:55","0");
INSERT INTO `auditoria` VALUES("64","admin ","Ha iniciado sesi&oacute;n","2017-11-27","15:39:18","0");



DROP TABLE IF EXISTS `configuracion`;

CREATE TABLE `configuracion` (
  `id_configuracion` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) NOT NULL,
  `siglas` varchar(60) NOT NULL,
  `sueldo` double(10,0) NOT NULL,
  `logo` varchar(60) NOT NULL,
  PRIMARY KEY (`id_configuracion`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `configuracion` VALUES("1","Centro de Alimentacion Pueblo Socialista","CDAPS","234215","logo.jpg");



DROP TABLE IF EXISTS `datos_personas`;

CREATE TABLE `datos_personas` (
  `id_datos_personas` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ciudad` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `municipio` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `parroquia` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `tipo_vivienda` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `condicion_vivienda` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `terrenodom` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trabaja` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `nombre_empresa` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fecha_ingreso` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `cargo_trabajo` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `empreproplab` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `actividad_economica` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'actividad economica, laboral ',
  `ingreso_fijo` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `otros_ingresos` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `gasto_total` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_datos_personas`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `datos_personas` VALUES("1","Aragua","El Consejo","JosÃ© Rafael Revenga","Trapiche del Medio","S/N","Rancho","Propia Pagada","","Si","","","","","","1111","","1110");
INSERT INTO `datos_personas` VALUES("2","Aragua","El Consejo","JosÃ© Rafael Revenga","El Consejo","S/N","Quinta","Prestada","","Si","","","","","","2536","","2537");
INSERT INTO `datos_personas` VALUES("3","Aragua","El Consejo","JosÃ© Rafael Revenga","El Consejo","S/N","Rancho","Propia Pagada","","No","","","","","","2500","","");
INSERT INTO `datos_personas` VALUES("4","Aragua","El Consejo","JosÃ© Rafael Revenga","El Consejo","s","Rancho","Propia Pagada","","No","","","","","","0","","");



DROP TABLE IF EXISTS `insumos`;

CREATE TABLE `insumos` (
  `id_insumos` int(11) NOT NULL AUTO_INCREMENT,
  `id_proveedores` int(11) NOT NULL,
  `codigo_insumo` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `tipo` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `marca` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_registro` date NOT NULL,
  PRIMARY KEY (`id_insumos`),
  KEY `id_proveedores` (`id_proveedores`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `insumos` VALUES("1","1","CDAPS-1","Frutas","Manzanas","Importadas","2017-11-24");



DROP TABLE IF EXISTS `inventario`;

CREATE TABLE `inventario` (
  `id_inventario` int(11) NOT NULL AUTO_INCREMENT,
  `id_insumos` int(11) NOT NULL,
  `estado` enum('Aceptado','Rechazado','','') COLLATE utf8_spanish_ci NOT NULL,
  `observaciones` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_entrega` date NOT NULL,
  `fecha_vencimiento` date NOT NULL,
  PRIMARY KEY (`id_inventario`),
  KEY `id_insumos` (`id_insumos`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `inventario` VALUES("1","1","Aceptado","1","5","2017-11-27","2017-11-26");



DROP TABLE IF EXISTS `menu_comida`;

CREATE TABLE `menu_comida` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `plato` varchar(50) NOT NULL,
  `jugo` varchar(50) NOT NULL,
  `merienda` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `menu_comida` VALUES("1","Pasticho","Guanabana","Pan","2017-11-26");



DROP TABLE IF EXISTS `observaciones`;

CREATE TABLE `observaciones` (
  `id_observaciones` int(11) NOT NULL AUTO_INCREMENT,
  `id_personas` int(11) NOT NULL,
  `motivo_eliminar` text NOT NULL,
  `fecha_eliminar` date NOT NULL,
  `motivo_beneficiar` int(11) NOT NULL,
  `fecha_beneficiar` date NOT NULL,
  PRIMARY KEY (`id_observaciones`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `personas`;

CREATE TABLE `personas` (
  `id_personas` int(11) NOT NULL AUTO_INCREMENT,
  `id_datos_personas` int(11) NOT NULL,
  `cedula` varchar(9) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `apellido` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sexo` enum('Masculino','Femenino') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `estado_civil` enum('Soltero(a)','Casado(a)','Viudo(a)','Divorciado(a)') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(11) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `lugar_nacimiento` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `nivel_estudio` enum('Primaria no Completa','Primaria Completa','Secundaria no Completa','Secundaria Completa','Técnico Medio','T.S.U.','Universitario') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `profesion` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `num_hijos` int(20) NOT NULL,
  `personas_cargo` int(20) NOT NULL,
  `discapacidad` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fecha_registro` date NOT NULL,
  `motivo_eliminar` text COLLATE utf8_spanish_ci NOT NULL,
  `motivo_beneficiar` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `estatus` enum('Censado(a)','Beneficiado(a)','Inhabilitado(a)','') COLLATE utf8_spanish_ci NOT NULL COMMENT 'Estado',
  PRIMARY KEY (`id_personas`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `personas` VALUES("1","1","12345678","Carla Stepha","Natera","Femenino","Casado(a)","04121234569","2015-07-01","La Victoria","Primaria Completa","Estudiante","2","2","","2017-08-10","","","Inhabilitado(a)");
INSERT INTO `personas` VALUES("2","2","87654321","Kathe","Manzo","Femenino","Divorciado(a)","04141236548","2015-07-07","La Victoria","T.S.U.","Trabajar","5","5","","2017-09-14","","","Inhabilitado(a)");
INSERT INTO `personas` VALUES("3","3","25364883","JosÃ©","LeÃ³n","Masculino","Soltero(a)","04121234569","2017-09-14","La Victoria","Primaria no Completa","Atleta","0","1","","2016-09-14","sda","Antoni Leon","Beneficiado(a)");
INSERT INTO `personas` VALUES("4","4","25364556","Centro de Alimentacion Pueblo","Manzo","Femenino","Soltero(a)","04123654852","2017-11-26","La Victoria","Primaria Completa","","1","1","s","2017-11-26","","","Censado(a)");



DROP TABLE IF EXISTS `proveedores`;

CREATE TABLE `proveedores` (
  `id_proveedores` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_rif` varchar(2) COLLATE utf8_spanish_ci NOT NULL,
  `rif` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `nombre_proveedor` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `direccion_proveedores` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `tipo_insumos` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_registro` date NOT NULL,
  `estatus` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_proveedores`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `proveedores` VALUES("1","G","253648836","Antoni","04123654852","","4dsa","","2017-11-24","Activo");



DROP TABLE IF EXISTS `seguimiento`;

CREATE TABLE `seguimiento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_persona` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `accion` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `observacion` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_persona` (`id_persona`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;




DROP TABLE IF EXISTS `tipo_insumos`;

CREATE TABLE `tipo_insumos` (
  `id_tipo_insumos` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_insumos` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_tipo_insumos`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tipo_insumos` VALUES("1","Secos");
INSERT INTO `tipo_insumos` VALUES("2","Frutas");
INSERT INTO `tipo_insumos` VALUES("3","Hortalizas");
INSERT INTO `tipo_insumos` VALUES("4","Verduras");
INSERT INTO `tipo_insumos` VALUES("5","Carne");
INSERT INTO `tipo_insumos` VALUES("6","Pollo");



DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipocuenta` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `apellido` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cedula` int(8) NOT NULL,
  `email` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `sexo` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ocupacion` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `direccion` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(11) COLLATE utf8_spanish_ci NOT NULL,
  `pregunta` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `respuesta` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `profile` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `registro` date NOT NULL,
  `status` varchar(2) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cedula` (`cedula`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `usuario` VALUES("1","Administrador(a)","Admin","81dc9bdb52d04dc20036dbd8313ed055","Carla","Natera","12345678","admin@gmail.com","M","Estudiante","El Consejo","04120360852","3","dios","Toni.jpg","2017-09-03","1");
INSERT INTO `usuario` VALUES("3","Supervisor(a)","login","81dc9bdb52d04dc20036dbd8313ed055","Supervisor","Supervisor","12345687","root@gmail.com","M","Estudiantes","Caracas","02443228569","3","dios","male.png","2017-09-20","1");
