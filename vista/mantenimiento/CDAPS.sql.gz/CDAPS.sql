-- Dump de la Base de Datos
-- Fecha: jueves 16 noviembre 2017 - 22:22:35
--
-- Version: 2.1.1, del 18 de Marzo de 2005, insidephp@gmail.com
-- Soporte y Updaters: http://insidephp.sytes.net
--
-- Host: `localhost`    Database: `cdaps`
-- ------------------------------------------------------
-- Server version	10.1.19-MariaDB


-- Dump de la Base de Datos Completo.